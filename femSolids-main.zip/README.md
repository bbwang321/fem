# femSolids

Finite Element Method based solver for solid and structural mechanics problems.

Sample input files are available in the `testcases` folder.


* Programming languages: **C++**
* C++ standard: **C++14** (or above)
* Required third-party libraries:
  1. CMake
  2. Blas
  3. Lapack
  4. Boost
  5. MPI (OpenMPI, MPICH or Intel MPI. Your choice!)
  6. [Eigen](http://eigen.tuxfamily.org/index.php?title=Main_Page)
  7. [METIS](http://glaros.dtc.umn.edu/gkhome/metis/metis/overview)
  8. [PETSc](https://www.mcs.anl.gov/petsc/)
  9. [VTK](https://vtk.org/)


## Compilation and building
1. Clone the repository.
2. Go to the directory of the repository in a terminal.
3. Create **build** and **bin** directories.
    * `mkdir build`
    * `mkdir bin`
4. Modify the CMake file accordingly.
    * Copy `CMakeLists.txt` to a new file for your machine, say `CMakeLists-local.txt`.
    * Change the paths to the compilers, Eigen, CGAL, PETSc and VTK libraries.
    * Change the path in the `install` function.
    * Create a symbolic link to the local CMake file.
      * `ln -sf CMakeLists-local.txt CMakeLists.txt`
5. Enter the `build` directory.
    * `cd build`
6. Configure using the CMake file
    * `cmake ..`
7. Compile, build and install the executable `femSolids`. This step will also copy the exe to the `bin` folder.
    * `make install`

## Execution
* Simulations are usually run from the `bin` folder, but you can append *bin* folder to the global `$PATH` variable and run from anywhere.
* Copy `petsc_options.dat` file from the `testcases` folder to the folder of your interest.
* For serial run: `femSolids  <inpfilename>` (White space between each entry)
* For parallel run: `mpirun -n <nprocs>  femSolids <inpfilename>`
* Example:
  * `femSolids  cookmembraneQ4-32d32.kck`
  * `mpirun -n 4 femSolids  cookmembraneQ4-32d32.kck`