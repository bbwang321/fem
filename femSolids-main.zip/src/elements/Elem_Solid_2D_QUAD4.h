
#ifndef incl_Elem_Solid_2D_QUAD4_h
#define incl_Elem_Solid_2D_QUAD4_h


#include "ElementBase.h"


class  Elem_Solid_2D_QUAD4 : public ElementBase
{
  public:

    Elem_Solid_2D_QUAD4();

    virtual ~Elem_Solid_2D_QUAD4();

    virtual ElemTypeNum getElmTypeNameNum()
    {  return ELEM_SOLID_2D_QUAD4; }

    virtual void prepareElemData();

    virtual int  calcMassMatrix(MatrixXd& Mlocal, bool MassLumping);

    virtual double calcCriticalTimeStep(bool flag);

    virtual double computeVolume(bool init = false);

    virtual int calcStiffnessAndResidual(MatrixXd& Klocal, VectorXd& Flocal);

    int calcStiffnessAndResidual_Formulation_Bbar(MatrixXd& Klocal, VectorXd& Flocal);

    int calcStiffnessAndResidual_Formulation_Mixed(MatrixXd& Klocal, VectorXd& Flocal);

    virtual int  calcResidual(VectorXd& Flocal);

    virtual void elementContourplot(int, int, int);

    virtual void projectToNodes(bool, int, int, int);

    virtual void projectStrain(bool, int, int, int, double*);

    virtual void projectStress(bool, int, int, int, double*);

    virtual void projectInternalVariable(bool, int, int, int, double*);

    virtual void computeEnergy(int, int, VectorXd&);
};







#endif


