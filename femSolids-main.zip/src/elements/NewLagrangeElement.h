
#ifndef  incl_newLagrangeElement_h
#define  incl_newLagrangeElement_h

#include "ElementBase.h"



#include "Elem_Solid_2D_QUAD4.h"
#include "Elem_Solid_2D_QUAD9.h"


#include "Elem_Solid_3D_HEXA8.h"


#include "Elem_Beam_2D_Nodes2.h"
#include "Elem_Shell_Flat_QUAD4.h"


inline  ElementBase*  NewLagrangeElement(int type)
{
  switch (type)
  {
    // 2D solid elements
    //
    //case  1: return (ElementBase*) new Elem_Solid_2D_TRIA3; break;

    case  ELEM_SOLID_2D_QUAD4: return (ElementBase*) new Elem_Solid_2D_QUAD4; break;

    //case  3: return (ElementBase*) new Elem_Solid_2D_TRIA6; break;

    //case  4: return (ElementBase*) new Elem_Solid_2D_QUAD8; break;

    case  ELEM_SOLID_2D_QUAD9: return (ElementBase*) new Elem_Solid_2D_QUAD9; break;


    // 3D solid elements
    //
    //case  21: return (ElementBase*) new Elem_Solid_3D_TETR4; break;

    //case  22: return (ElementBase*) new Elem_Solid_3D_PYRM5; break;

    //case  23: return (ElementBase*) new Elem_Solid_3D_WEDG6; break;

    case  ELEM_SOLID_3D_HEXA8: return (ElementBase*) new Elem_Solid_3D_HEXA8; break;

    //case  25: return (ElementBase*) new Elem_Solid_3D_TETR10; break;

    //case  26: return (ElementBase*) new Elem_Solid_3D_PYRM13; break;

    //case  27: return (ElementBase*) new Elem_Solid_3D_PYRM14; break;

    //case  28: return (ElementBase*) new Elem_Solid_3D_WEDG15; break;

    //case  29: return (ElementBase*) new Elem_Solid_3D_WEDG18; break;

    //case  30: return (ElementBase*) new Elem_Solid_3D_HEXA20; break;

    //case  31: return (ElementBase*) new Elem_Solid_3D_HEXA27; break;


    // 2D truss and beam elements
    //
    case  ELEM_BEAM_2D_NODES2: return (ElementBase*) new Elem_Beam_2D_Nodes2; break;

    //case  63: return (ElementBase*) new Elem_Beam_2D_Nodes3; break;

    // 3D truss and beam elements
    //
    //case  81: return (ElementBase*) new Elem_Truss_3D_Nodes2; break;

    //case  82: return (ElementBase*) new Elem_Beam_3D_Nodes2; break;

    //case  83: return (ElementBase*) new Elem_Beam_3D_Nodes3; break;

    case  ELEM_SHELL_FLAT_QUAD4: return (ElementBase*) new Elem_Shell_Flat_QUAD4; break;

    default:
      cerr << " unknown element type name in NewLagrangeElement ... " << endl;
  }
}


#endif

