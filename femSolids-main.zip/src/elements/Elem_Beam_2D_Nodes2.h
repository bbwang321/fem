
#ifndef incl_Elem_Beam_2D_Nodes2_h
#define incl_Elem_Beam_2D_Nodes2_h


#include "ElementBase.h"



class  Elem_Beam_2D_Nodes2 : public ElementBase
{
  public:

    Elem_Beam_2D_Nodes2();

    virtual ~Elem_Beam_2D_Nodes2();

    virtual ElemTypeNum getElmTypeNameNum()
    {  return ELEM_BEAM_2D_NODES2; }

    virtual void prepareElemData();

    virtual int  calcStiffnessAndResidual(MatrixXd& Klocal, VectorXd& Flocal);

    int  calcStiffnessAndResidual_Linear(MatrixXd& Klocal, VectorXd& Flocal);
    int  calcStiffnessAndResidual_Nonlinear(MatrixXd& Klocal, VectorXd& Flocal);

    virtual int calcInternalForces();

    virtual int calcLoadVector(VectorXd& Flocal);

    virtual int calcOutput(double u1, double v1);

    virtual void elementContourplot(int, int, int);

    virtual void projectToNodes(bool, int, int, int);

    virtual void projectStrain(bool, int, int, int, double*);

    virtual void projectStress(bool, int, int, int, double*);

    virtual void projectInternalVariable(bool, int, int, int, double*);
};

#endif

