
#ifndef incl_Elem_Shell_Flat_QUAD4_h
#define incl_Elem_Shell_Flat_QUAD4_h


#include "ElementBase.h"


class  Elem_Shell_Flat_QUAD4 : public ElementBase
{
  public:

    Elem_Shell_Flat_QUAD4();

    virtual ~Elem_Shell_Flat_QUAD4();

    virtual ElemTypeNum getElmTypeNameNum()
    {  return ELEM_SHELL_FLAT_QUAD4; }

    virtual void prepareElemData();

    virtual int  calcStiffnessAndResidual(MatrixXd& Klocal, VectorXd& Flocal);

    virtual int calcInternalForces();

    virtual int calcLoadVector(VectorXd& Flocal);

    virtual void elementContourplot(int, int, int);

    virtual void projectToNodes(bool, int, int, int);

    virtual void projectStrain(bool, int, int, int, double*);

    virtual void projectStress(bool, int, int, int, double*);

    virtual void projectInternalVariable(bool, int, int, int, double*);

};

#endif

