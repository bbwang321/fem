
#ifndef incl_femSolids_CLASS_h
#define incl_femSolids_CLASS_h
#define EIGEN_SUPERLU_SUPPORT

#include "util.h"
#include "GeomDataLagrange.h"
#include "SolutionDataSolid.h"
#include "headersVTK.h"
#include "ElementBase.h"
#include "MaterialBase.h"
#include "SolverPetsc.h"
#include "Domain.h"
#include "ElementTypeData.h"
#include "headersBasic.h"



using std::vector;
using std::cout;
using std::string;
using std::ofstream;

class ElementBase;




class femSolids
{
    private:
    //public:

        string    infilename, dirname, jobname;

        int  ndim, ndof;

        int  numTRIA3, numTRIA6, numQUAD4, numQUAD8, numQUAD9;
        int  numTETRA4, numPYRAM5, numWEDGE6, numHEXA8, numTETRA10, numPYRAM13, numPYRAM14, numWEDGE15, numWEDGE18, numHEXA20, numHEXA27;

        int  stepsMax, iterationsMax, outputFreq, fileCount;
        int  nElem_global, nNode_global, nElem_local, nNode_local, nNode_owned;
        int  n_mpi_procs, this_mpi_proc;
        int  node_start, node_end, elem_start, elem_end;
        int  row_start, row_end, ntotdofs_local, ntotdofs_global;

        int  dispDOF, presDOF, totalDOF;
        int  numMaterials;
        int  numElemTypes;
        int  numNodalForces;
        int  numSPCs;
        int  outputfrequency;

        SolverType   NONLINEAR_SOLVER_TYPE;
        int  AlgoType, SCHEME_TYPE;

        bool  solverOK, firstIteration, loadStepConverged;
        bool  localStiffnessError, intVarFlag, IMPLICIT_SOLVER, MIXED_ELEMENT;
        bool  ARC_LENGTH, convergedFlagPrev, convergedFlag;

        double  arclenIncr, arclenIncrPrev, arclenIncrMax, arclenIncrMin;
        double  loadFactor, loadFactorPrev, loadFactorPrev2;


        vector<NodalBC>      NodalBCs;
        vector<NodalForce>   NodalForces;
        vector<string>   outputlist_nodal,  outputlist_elemental;

        VectorXd  solnIncrStep, solnIncrIter;

        vector<double>  loadfactorVec;
        vector<vector<double> >  OutputData, nodeForcesData;

        ElementBase  **elems;

        SolutionDataSolid  SolnData;
        GeomDataLagrange  GeomData;

        PetscErrorCode  errpetsc;

        double    computerTimeAssembly, computerTimeSolver, computerTimePostprocess, computerTimePattern, computerTimeTimeLoop;
        double    conv_tol, timeFinal, rhsNorm, rhsNormPrev;

        VectorXd  td, reacVec;

        vector<int>              assyForSoln, dofs_specified, dofs_specified_pres;
        vector<int>              elem_proc_id, node_proc_id, node_map_get_old, node_map_get_new;
        vector<vector<int> >     elemConn, node_elem_conn;
        vector<vector<int> >     NodeDofArray, forAssyVecAll, globalDOFnumsAll;
        vector<vector<bool> >    NodeType;
        vector<vector<int> >     midnodeData;


        vector<ElementTypeData*>  ElementTypeDataList;
        vector<MaterialBase*>    MatlDataList;

        unique_ptr<SolverPetsc>  solverPetsc;

    public:

        femSolids();

        ~femSolids();

        ///////////////////////////////////////////////////////////
        //
        // PRE-PROCESSOR PHASE member functions
        //
        ///////////////////////////////////////////////////////////
        
        void  setJobName(string& jname)
        {
            jobname = jname;
            return;
        }

        int  readInputData(string& fname);

        int  readInputMine(ifstream& infile);

        int  readInputBDF(ifstream& infile);

        int  readConfiguration(string& fname);

        int  readModelType(ifstream& infile, string& line);

        int  readNodes(ifstream& infile, string& line);

        int  readSolidElements(ifstream& infile, string& line);

        int  readSurfaceElements(ifstream& infile, string& line);

        int  readPrescribedBCs(ifstream& infile, string& line);

        int  readNodalForces(ifstream& infile, string& line);

        int  readBodyForce(ifstream& infile, string& line);

        int  readInitialConditions(ifstream& infile, string& line);

        int  readSolverDetails(ifstream& infile, string& line);

        int  readSolverDetails(string& fname);

        int  readTimeFunctions(ifstream& infile, string& line);

        int  deallocatePetscObjects();

        int  readElementProps(ifstream& infile, string& line);

        int  readMaterialProps(ifstream& infile, string& line);

        int  readOutputDetails(ifstream& infile, string& line);

        int  readNodalDataForOutput(ifstream& infile, string& line);

        int  prepareInputData();

        int  partitionMesh();

        int  printInfo();

        int  plotGeom(int, bool, int, bool, int*);

        int  applyExternalForces();

        int  writeNodalData();

        int  writeReadResult(int, string&);

        int  prepareDataForMixedElements();

        ///////////////////////////////////////////////////////////
        //
        // SOLUTION PHASE member functions
        //
        ///////////////////////////////////////////////////////////

        int  solveWithNewtonRaphson();

        int  solveWithArclength();

        int  setSolver(int);

        int  prepareMatrixPattern();

        int  setSolverDataForFullyImplicit();

        bool converged();

        bool diverging(double);

        int  timeUpdate();

        int  updateIterStep();

        int  reset();

        int  saveSolution();

        int  addExternalForces();

        int  addBoundaryConditions();

        int  setSpecifiedDOFs(vector<vector<bool> >& NodeType);

        int  setBoundaryConditions();

        int  setInitialConditions();

        int  solveFullyImplicit();

        int  calcStiffnessAndResidual();

        int  factoriseSolveAndUpdate();

        int  copyElemInternalVariables();

        int  calcMassMatrixForExplicitDynamics();

        int  ModalAnalysis(int nn=10, bool flag=true, double fact=1.0);

        ///////////////////////////////////////////////////////////
        //
        // POST-PROCESSOR PHASE member functions
        //
        ///////////////////////////////////////////////////////////

        int  postProcess();

        int  projectStrains(bool, int, int, int);

        int  projectStresses(bool, int, int, int);

        int  projectInternalVariables(bool, int, int, int);

        int  computeElementErrors(int);
};






#endif






