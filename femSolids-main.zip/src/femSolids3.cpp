
#include "femSolids.h"
#include "headersVTK.h"
#include "MyTime.h"
#include "metis.h"

extern  MyTime myTime;
extern  bool debug;


int  femSolids::partitionMesh()
{
    PetscPrintf(MPI_COMM_WORLD, "\n     femSolids::partitionMesh()  .... STARTED ...\n");

    int this_mpi_proc, n_mpi_procs;

    MPI_Comm_size(MPI_COMM_WORLD, &n_mpi_procs);
    MPI_Comm_rank(MPI_COMM_WORLD, &this_mpi_proc);

    int  ee, ii, jj, kk, n1, n2, npElem;
    int  nparts = n_mpi_procs, subdomain=0;

    if(this_mpi_proc == 0)
    {
        /////////////////////////////////////////////////////////////////////////////
        //
        // Partition the mesh. Here, METIS is used.
        // 
        /////////////////////////////////////////////////////////////////////////////

        npElem = elemConn[0].size()-5;

        PetscInt  *eptr, *eind;

        errpetsc  = PetscMalloc1(nElem_global+1,  &eptr);CHKERRQ(errpetsc);
        errpetsc  = PetscMalloc1(nElem_global*npElem,  &eind);CHKERRQ(errpetsc);

        vector<int>  vecTemp2;

        eptr[0] = 0;
        kk = 0;
        for(ee=0; ee<nElem_global; ee++)
        {
            eptr[ee+1] = (ee+1)*npElem;

            vecTemp2 = elemConn[ee];
            //printVector(vecTemp2);

            npElem = elemConn[ee].size()-5;

            for(ii=0; ii<npElem; ii++)
              eind[kk+ii] = vecTemp2[5+ii];

            kk += npElem;
        }

        int  ncommon_nodes;
        if(ndim == 2)
        {
          if( (npElem == 3) || (npElem == 4) )       // 3-noded tria or 4-noded quad elements
            ncommon_nodes = 2;
          else
            ncommon_nodes = 3;  // 6-noded tria or 9-noded quad elements
        }
        else
        {
          if(npElem == 4)          // 4-noded tetra element
            ncommon_nodes = 3;
          else if(npElem == 10)    // 10-noded tetra element
            ncommon_nodes = 6;
          else if(npElem == 6)     // 6-noded Wedge/Prism element
            ncommon_nodes = 4;
          else if(npElem == 8)     // 8-noded hexa element
            ncommon_nodes = 4;
          else if(npElem == 18)    // 18-noded Wedge/Prism element
            ncommon_nodes = 9;
          else
            ncommon_nodes = 9;     // 27-noded hexa element
        }

        idx_t objval;
        idx_t options[METIS_NOPTIONS];

        METIS_SetDefaultOptions(options);

        // Specifies the partitioning method.
        //options[METIS_OPTION_PTYPE] = METIS_PTYPE_RB;          // Multilevel recursive bisectioning.
        options[METIS_OPTION_PTYPE] = METIS_PTYPE_KWAY;        // Multilevel k-way partitioning.

        //options[METIS_OPTION_NSEPS] = 10;

        //options[METIS_OPTION_OBJTYPE] = METIS_OBJTYPE_CUT;     // Edge-cut minimization
        options[METIS_OPTION_OBJTYPE] = METIS_OBJTYPE_VOL;     // Total communication volume minimization

        options[METIS_OPTION_NUMBERING] = 0;  // C-style numbering is assumed that starts from 0.

        cout << " Executing METIS subroutine " << endl;

        // METIS partition routine
        int ret = METIS_PartMeshNodal(&nElem_global, &nNode_global, eptr, eind, NULL, NULL, &nparts, NULL, options, &objval, &elem_proc_id[0], &node_proc_id[0]);
        //int ret = METIS_PartMeshDual(&nElem_global, &nNode_global, eptr, eind, NULL, NULL, &ncommon_nodes, &nparts, NULL, options, &objval, &elem_proc_id[0], &node_proc_id[0]);

        if(ret == METIS_OK)
          cout << " METIS partition routine successful "  << endl;
        else
          cout << " METIS partition routine FAILED "  << endl;

        errpetsc = PetscFree(eptr); CHKERRQ(errpetsc);
        errpetsc = PetscFree(eind); CHKERRQ(errpetsc);

        if( 1 < 0)
        {
          for(ee=0; ee<nNode_global; ee++)
            cout << ee << '\t' << node_proc_id[ee] << endl;
          cout << endl;  cout << endl;  cout << endl;

          for(ee=0; ee<nElem_global; ee++)
            cout << ee << '\t' << elem_proc_id[ee] << endl;
          cout << endl;  cout << endl;  cout << endl;
        }
    }
    MPI_Barrier(MPI_COMM_WORLD);

    errpetsc = MPI_Bcast(&elem_proc_id[0], nElem_global, MPI_INT, 0, MPI_COMM_WORLD); CHKERRQ(errpetsc);
    MPI_Barrier(MPI_COMM_WORLD);

    errpetsc = MPI_Bcast(&node_proc_id[0], nNode_global, MPI_INT, 0, MPI_COMM_WORLD); CHKERRQ(errpetsc);
    MPI_Barrier(MPI_COMM_WORLD);

    nElem_local = std::count(elem_proc_id.begin(), elem_proc_id.end(), this_mpi_proc);
    cout << " nElem_local =  " << nElem_local << '\t' << this_mpi_proc << '\t' << n_mpi_procs << endl;


    nNode_owned = std::count(node_proc_id.begin(), node_proc_id.end(), this_mpi_proc);
    cout << " nNode_owned =  " << nNode_owned << '\t' << this_mpi_proc << '\t' << n_mpi_procs << endl;

    MPI_Barrier(MPI_COMM_WORLD);

    // find nodes local to each processor generate the list of locally owned nodes
    std::vector<int>  nodelist_owned(nNode_owned);

    kk=0;
    for(ii=0; ii<nNode_global; ii++)
    {
        if( node_proc_id[ii] == this_mpi_proc )
        {
          nodelist_owned[kk++] = ii;
        }
    }
    //cout << " Locally owned nodes " << '\t' << this_mpi_proc << endl;
    //printVector(nodelist_owned);

    MPI_Barrier(MPI_COMM_WORLD);

    // create the vector (of size n_mpi_procs)
    // consisting of nNode_owned from all the processors in the communication
    vector<int>  nNode_owned_vector(n_mpi_procs), nNode_owned_sum(n_mpi_procs);

    MPI_Allgather(&nNode_owned, 1, MPI_INT, &nNode_owned_vector[0], 1, MPI_INT, MPI_COMM_WORLD);
    //printVector(nNode_owned_vector);

    // compute the numbers of first and last nodes in the local processor
    nNode_owned_sum = nNode_owned_vector;
    for(ii=1; ii<n_mpi_procs; ii++)
    {
      nNode_owned_sum[ii] += nNode_owned_sum[ii-1];
    }
    //printVector(nNode_owned_sum);
    node_start = 0;
    if(this_mpi_proc > 0)
      node_start = nNode_owned_sum[this_mpi_proc-1];
    node_end   = nNode_owned_sum[this_mpi_proc]-1;

    cout << " node_start =  " << node_start << '\t' << node_end << '\t' << this_mpi_proc << endl;

    MPI_Barrier(MPI_COMM_WORLD);

    std::vector<int>  displs(n_mpi_procs);

    displs[0] = 0;
    for(ii=0; ii<n_mpi_procs-1; ii++)
      displs[ii+1] = displs[ii] + nNode_owned_vector[ii];

    // create a global list of nodelist_owned
    // which will serve as a mapping from NEW node numbers to OLD node numbers
    errpetsc = MPI_Allgatherv(&nodelist_owned[0], nNode_owned, MPI_INT, &node_map_get_old[0], &nNode_owned_vector[0], &displs[0], MPI_INT, MPI_COMM_WORLD);


    // create an array for mapping from OLD node numbers to NEW node numbers
    // Also, generate NodeTypeNew array for computing the local and global DOF size
    // as well as creating the element-wise array for element matrix/vector assembly
    for(ii=0; ii<nNode_global; ii++)
    {
      n1 = node_map_get_old[ii];
      node_map_get_new[n1] = ii;
    }

    // update elem<->node connectivity with new node numbers and delete arrays in other processors
    //vector<int>  vecTemp;
    for(ee=0; ee<nElem_global; ee++)
    {
      npElem = elemConn[ee].size()-3;

      for(ii=0; ii<npElem; ii++)
        elemConn[ee][3+ii] = node_map_get_new[elemConn[ee][3+ii]];
    }
    MPI_Barrier(MPI_COMM_WORLD);

    // update node numbers for boundary conditions and loads
    // update Dirichlet BC information with new node numbers
    //
    for(ii=0; ii<NodalBCs.size(); ii++)
    {
        NodalBCs[ii].nodeNum = node_map_get_new[NodalBCs[ii].nodeNum];
    }

    for(ii=0; ii<NodalForces.size(); ii++)
    {
        NodalForces[ii].nodeNum = node_map_get_new[NodalForces[ii].nodeNum];
    }

    // update nodal coordinates as per the new node numbers
    GeomData.node_map_get_old = node_map_get_old;
    GeomData.node_map_get_new = node_map_get_new;
    GeomData.updateNodesAfterPartition();
    
    MPI_Barrier(MPI_COMM_WORLD);
    
    PetscPrintf(MPI_COMM_WORLD, "\n     femSolids::partitionMesh()  .... FINISHED ...\n");

    return 0;
}





int  femSolids::postProcess()
{
    if(this_mpi_proc != 0)
      return 0;

    if(debug) PetscPrintf(MPI_COMM_WORLD, " \n femSolids::postProcess \n");

    //
    // setup and write vtk data
    //
    //////////////////////////////////////////////


    vtkSmartPointer<vtkUnstructuredGrid>     uGridVTK     =  vtkSmartPointer<vtkUnstructuredGrid>::New();
    vtkSmartPointer<vtkPoints>               pointsVTK    =  vtkSmartPointer<vtkPoints>::New();
    vtkSmartPointer<vtkVertex>               vertexVTK    =  vtkSmartPointer<vtkVertex>::New();

    vtkSmartPointer<vtkLine>                 lineVTK      =  vtkSmartPointer<vtkLine>::New();
    vtkSmartPointer<vtkTriangle>             triaVTK      =  vtkSmartPointer<vtkTriangle>::New();
    vtkSmartPointer<vtkQuad>                 quadVTK      =  vtkSmartPointer<vtkQuad>::New();
    vtkSmartPointer<vtkTetra>                tetraVTK     =  vtkSmartPointer<vtkTetra>::New();
    vtkSmartPointer<vtkWedge>                wedgeVTK     =  vtkSmartPointer<vtkWedge>::New();
    vtkSmartPointer<vtkHexahedron>           hexaVTK      =  vtkSmartPointer<vtkHexahedron>::New();

    vtkSmartPointer<vtkQuadraticTriangle>    tria6VTK     =  vtkSmartPointer<vtkQuadraticTriangle>::New();
    vtkSmartPointer<vtkBiQuadraticQuad>      quad9VTK     =  vtkSmartPointer<vtkBiQuadraticQuad>::New();
    vtkSmartPointer<vtkQuadraticTetra>       tetra10VTK   =  vtkSmartPointer<vtkQuadraticTetra>::New();
    vtkSmartPointer<vtkBiQuadraticQuadraticWedge>  wedge18VTK = vtkSmartPointer<vtkBiQuadraticQuadraticWedge>::New();
    vtkSmartPointer<vtkQuadraticHexahedron>  hexa27VTK    =  vtkSmartPointer<vtkQuadraticHexahedron>::New();

    vtkSmartPointer<vtkFloatArray>           vecVTK       =  vtkSmartPointer<vtkFloatArray>::New();
    vtkSmartPointer<vtkFloatArray>           vecVTK2      =  vtkSmartPointer<vtkFloatArray>::New();
    vtkSmartPointer<vtkFloatArray>           scaVTK       =  vtkSmartPointer<vtkFloatArray>::New();
    vtkSmartPointer<vtkFloatArray>           scaVTK2      =  vtkSmartPointer<vtkFloatArray>::New();

    vtkSmartPointer<vtkFloatArray>           cellDataVTK  =  vtkSmartPointer<vtkFloatArray>::New();
    vtkSmartPointer<vtkFloatArray>           cellDataVTK2 =  vtkSmartPointer<vtkFloatArray>::New();
    vtkSmartPointer<vtkFloatArray>           strainVTK    =  vtkSmartPointer<vtkFloatArray>::New();
    vtkSmartPointer<vtkFloatArray>           stressVTK    =  vtkSmartPointer<vtkFloatArray>::New();
    vtkSmartPointer<vtkFloatArray>           procIdVTKcell =  vtkSmartPointer<vtkFloatArray>::New();

    vtkSmartPointer<vtkFloatArray>           timeloadstamp  =  vtkSmartPointer<vtkFloatArray>::New();

    vtkSmartPointer<vtkXMLUnstructuredGridWriter>  writerUGridVTK =  vtkSmartPointer<vtkXMLUnstructuredGridWriter>::New();


    int  dd, ii, jj, kk, ll, nn, nlocal, ind1, ind2, e, ee, count, gcount, ind, npElem;
    int  n1, n2, n3, n4, n5, n6;
    double vec[3]={0.0,0.0,0.0}, vec2[3]={0.0,0.0,0.0}, xx, yy, zz, val, maxdisp = 0.0, maxstress = 0.0;
    //                        {0,1,2,3,4,5,6,7,8,9, 10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26};
    int  hexa27nodemap[27] =  {0,1,2,3,4,5,6,7,8,11,16, 9,17,10,18,19,12,15,13,14,24,22,20,21,23,25,26};
    //                        {0,1,2,3,4,5,6,7, 8,9,10,11,12,13,14,15,16,17};
    int  wedge18nodemap[18] = {0,1,2,3,4,5,6,8,12,7,13,14, 9,11,10,15,17,16};
    //                        {0,1,2,3,4,5,6,7,8,9};
    int  tetra10nodemap[10] = {0,1,2,3,4,5,6,7,9,8};

    int vartype=0, varindex=0, index=0;
    bool extrapolateFlag=true;
    vector<int>  nodeNums;

    vtkIdType pt[50];

    vecVTK->SetName("disp");
    //vecVTK2->SetName("velo");
    //if(ndof > 1)
    //{
      vecVTK->SetNumberOfComponents(3);
      vecVTK->SetNumberOfTuples(nNode_global);
      //vecVTK2->SetNumberOfComponents(3);
      //vecVTK2->SetNumberOfTuples(nNode_global);
    //}

    //procIdVTKcell->SetName("procID");
    //procIdVTKcell->SetNumberOfTuples(nElem_global);

    timeloadstamp->SetName("TIME");
    timeloadstamp->SetNumberOfTuples(1);
    if(ARC_LENGTH)
      timeloadstamp->SetTuple1(0, loadFactor);
    else
      timeloadstamp->SetTuple1(0, myTime.cur);


    //int idd = SolnData.ElemProp[0].id;
    int idd = 2;


    if(ndim == 2)
    {
      for(ii=0;ii<nNode_global;ii++)
      {
          nn = node_map_get_new[ii];

          xx = GeomData.NodePosNew[nn][0];
          yy = GeomData.NodePosNew[nn][1];
          
          pt[0] = pointsVTK->InsertNextPoint(xx, yy, 0.0);

          vertexVTK->GetPointIds()->SetId(0, pt[0]);

          kk = nn*ndof;

          vec[0] = SolnData.disp[kk];
          vec[1] = SolnData.disp[kk+1];

          vecVTK->InsertTuple(ii, vec);

          //vec[0] = SolnData.velo[kk];
          //vec[1] = SolnData.velo[kk+1];

          //vec[0] = SolnData.acce[kk];
          //vec[1] = SolnData.acce[kk+1];

          //vecVTK2->InsertTuple(ii, vec);
      }


      for(ee=0; ee<nElem_global; ee++)
      {
        //procIdVTKcell->SetTuple1(ee, elem_proc_id[ee]);

        nodeNums = elems[ee]->nodeNums;
        npElem   = nodeNums.size();

        if(npElem == 2)
        {
          lineVTK->GetPointIds()->SetId(0, node_map_get_old[nodeNums[0]]);
          lineVTK->GetPointIds()->SetId(1, node_map_get_old[nodeNums[1]]);

          uGridVTK->InsertNextCell(lineVTK->GetCellType(), lineVTK->GetPointIds());
        }
        else if(npElem == 3)
        {
          for(ii=0; ii<npElem; ii++)
            triaVTK->GetPointIds()->SetId(ii, node_map_get_old[nodeNums[ii]]);

          uGridVTK->InsertNextCell(triaVTK->GetCellType(), triaVTK->GetPointIds());
        }
        else if(npElem == 6)
        {
          for(ii=0; ii<npElem; ii++)
            tria6VTK->GetPointIds()->SetId(ii, nodeNums[ii]);

          uGridVTK->InsertNextCell(tria6VTK->GetCellType(), tria6VTK->GetPointIds());
        }
        else if(npElem == 4)
        {
          for(ii=0; ii<npElem; ii++)
            quadVTK->GetPointIds()->SetId(ii, node_map_get_old[nodeNums[ii]]);

          uGridVTK->InsertNextCell(quadVTK->GetCellType(), quadVTK->GetPointIds());
        }
        else if(npElem == 9)
        {
          for(ii=0; ii<npElem; ii++)
            quad9VTK->GetPointIds()->SetId(ii, nodeNums[ii]);

          uGridVTK->InsertNextCell(quad9VTK->GetCellType(), quad9VTK->GetPointIds());
        }
        else
        {
          PetscPrintf(MPI_COMM_WORLD, "\n\n Wrong 2D element type for post-processing \n\n");
          exit(1);
        }
      }
    }
    else //if(ndim == 3)
    {
      for(ii=0;ii<nNode_global;ii++)
      {
          xx = GeomData.NodePosNew[ii][0];
          yy = GeomData.NodePosNew[ii][1];
          zz = GeomData.NodePosNew[ii][2];

          pt[0] = pointsVTK->InsertNextPoint(xx, yy, zz);

          vertexVTK->GetPointIds()->SetId(0, pt[0]);

          kk = ii*ndof;

          vec[0] = SolnData.disp[kk];
          vec[1] = SolnData.disp[kk+1];
          vec[2] = SolnData.disp[kk+2];

          vecVTK->InsertTuple(ii, vec);

          //vec[0] = SolnData.velo[kk];
          //vec[1] = SolnData.velo[kk+1];
          //vec[2] = SolnData.velo[kk+2];

          //vecVTK2->InsertTuple(ii, vec);
      }


      for(ee=0; ee<nElem_global; ee++)
      {
        //procIdVTKcell->SetTuple1(ee, elem_proc_id[ee]);

        nodeNums = elems[ee]->nodeNums;
        npElem   = nodeNums.size();

        if(npElem == 4) // tet
        {
          if(elems[ee]->ElemTypeData->getElemTypeNameNum() == ELEM_SOLID_3D_TETR4)
          {
            for(ii=0; ii<npElem; ii++)
              tetraVTK->GetPointIds()->SetId(ii, nodeNums[ii]);

            uGridVTK->InsertNextCell(tetraVTK->GetCellType(), tetraVTK->GetPointIds());
          }
          else
          {
            for(ii=0; ii<npElem; ii++)
              quadVTK->GetPointIds()->SetId(ii, nodeNums[ii]);

            uGridVTK->InsertNextCell(quadVTK->GetCellType(), quadVTK->GetPointIds());
          }
        }
        else if(npElem == 6)
        {
          for(ii=0; ii<npElem; ii++)
            wedgeVTK->GetPointIds()->SetId(ii, nodeNums[ii]);

          uGridVTK->InsertNextCell(wedgeVTK->GetCellType(), wedgeVTK->GetPointIds());
        }
        else if(npElem == 8) // hexa
        {
          for(ii=0; ii<npElem; ii++)
            hexaVTK->GetPointIds()->SetId(ii, nodeNums[ii]);

          uGridVTK->InsertNextCell(hexaVTK->GetCellType(), hexaVTK->GetPointIds());
        }
        else if(npElem == 10) // 10-node tetrahedron
        {
          for(ii=0; ii<npElem; ii++)
            tetra10VTK->GetPointIds()->SetId(tetra10nodemap[ii], nodeNums[ii]);

          uGridVTK->InsertNextCell(tetra10VTK->GetCellType(), tetra10VTK->GetPointIds());
        }
        else if(npElem == 18) // 18-node wedge
        {
          for(ii=0; ii<npElem; ii++)
            wedge18VTK->GetPointIds()->SetId(wedge18nodemap[ii], nodeNums[ii]);

          uGridVTK->InsertNextCell(wedge18VTK->GetCellType(), wedge18VTK->GetPointIds());
        }
        else if(npElem == 27) // 27-node hexahedron
        {
          for(ii=0; ii<npElem; ii++)
            wedge18VTK->GetPointIds()->SetId(hexa27nodemap[ii], nodeNums[ii]);

          uGridVTK->InsertNextCell(wedge18VTK->GetCellType(), wedge18VTK->GetPointIds());
        }
        else
        {
          PetscPrintf(MPI_COMM_WORLD, "\n\n Wrong 3D element type for post-processing \n\n");
          exit(1);
        }
      }
    }

    //cout << " vartype " << endl;
    //cout << vartype << '\t' << varindex << '\t' << index << endl;

    cellDataVTK->SetName("pres");
    cellDataVTK->SetNumberOfTuples(nElem_global);
    for(ee=0;ee<nElem_global;ee++)
    {
      //TODO
      //elems[ee]->elementContourplot(vartype, varindex, index);

      //cellDataVTK->InsertTuple1(ee, elems[ee]->vals2project[0]);

      //maxstress = max(maxstress, elems[ee]->vals2project[0]);
    }

    if(intVarFlag)
    {
      scaVTK2->SetName("epstrn");
      scaVTK2->SetNumberOfTuples(count);
      projectStresses(1, 5, 6, index);
    }

    scaVTK->SetName("pres");
    scaVTK->SetNumberOfTuples(count);

    //cout << vartype << '\t' << varindex << '\t' << index << endl;

    //projectStresses(extrapolateFlag, vartype, varindex, index);
    //cout << vartype << '\t' << varindex << '\t' << index << endl;
    //projectFromElemsToNodes(extrapolateFlag, vartype, varindex, index);


    uGridVTK->SetPoints(pointsVTK);
    uGridVTK->GetFieldData()->AddArray(timeloadstamp);
    //uGridVTK->GetPointData()->AddArray(scaVTK);
    uGridVTK->GetPointData()->AddArray(vecVTK);
    //uGridVTK->GetPointData()->AddArray(vecVTK2);
    //uGridVTK->GetCellData()->AddArray(procIdVTKcell);
    //if(intVarFlag)
      //uGridVTK->GetPointData()->AddArray(scaVTK2);


    //Write the file
    char VTKfilename[200];
    sprintf(VTKfilename,"%s%s%06d%s", jobname.c_str(), "-",fileCount,".vtu");

    writerUGridVTK->SetFileName(VTKfilename);
    writerUGridVTK->SetInputData(uGridVTK);
    writerUGridVTK->Write();

    fileCount++;

    return 0;
}



int  femSolids::projectStrains(bool extrapolateFlag, int vartype, int varindex, int index)
{
    return 0;
}



int  femSolids::projectStresses(bool extrapolateFlag, int vartype, int varindex, int index)
{
    int  ee, ii;

    //cout << " extrapolateFlag = " << extrapolateFlag << endl;

    // compute the stresses at element nodes
    for(ee=0; ee<nElem_global; ee++)
    {
      elems[ee]->projectToNodes(extrapolateFlag, vartype, varindex, index);
    }

    vector<int>  nodeNums;
    vector<double>  output(nNode_global, 0.0);
    double  volu, val;

    for(ee=0; ee<nElem_global; ee++)
    {
      nodeNums = elems[ee]->nodeNums;

      elems[ee]->computeVolume(false);

      volu = elems[ee]->getVolume();

      //cout << " volu= " << volu << endl;

      for(ii=0; ii<nodeNums.size(); ii++)
      {
        //output[nodeNums[ii]] += volu*elems[ee]->vals2project[ii];
        output[nodeNums[ii]] += elems[ee]->vals2project[ii];
      }
    }

    for(ee=0; ee<nNode_global; ee++)
    {
      //printVector(node_elem_conn[ee]);
      volu = 0.0;
      for(ii=0; ii<node_elem_conn[ee].size(); ii++)
      {
        volu += elems[node_elem_conn[ee][ii]]->getVolume();
      }

      //output[ee] /= volu;
      output[ee] /= node_elem_conn[ee].size();
    }

    // for Bernstein elements, the values for midnodes need to be interpolated
    // Only to be done when the values are extrapolated from Gauss points
    //if(extrapolateFlag)
    //{
      for(ii=0; ii<nNode_global; ii++)
      {
        if( midnodeData[ii][0] )
        {
          val  = 0.50*output[ii];
          val += 0.25*output[midnodeData[ii][1]];
          val += 0.25*output[midnodeData[ii][2]];

          //scaVTK->SetTuple1(ii, val);
        }
        //else
          //scaVTK->SetTuple1(ii, output[ii]);
      }
    //}

    //cout << " extrapolateFlag = " << extrapolateFlag << endl;

    return 0;
}


int  femSolids::projectInternalVariables(bool extrapolateFlag, int vartype, int varindex, int index)
{
    return 0;
}






/*
int  femSolids::postProcess()
{
    cout << " femSolids::postProcess " << endl;

    //
    // setup and write vtk data
    //
    //////////////////////////////////////////////


    vtkSmartPointer<vtkUnstructuredGrid>     uGridVTK     =  vtkSmartPointer<vtkUnstructuredGrid>::New();
    vtkSmartPointer<vtkPoints>               pointsVTK    =  vtkSmartPointer<vtkPoints>::New();
    vtkSmartPointer<vtkVertex>               vertexVTK    =  vtkSmartPointer<vtkVertex>::New();

    vtkSmartPointer<vtkLine>                 lineVTK      =  vtkSmartPointer<vtkLine>::New();

    vtkSmartPointer<vtkTriangle>             triaVTK      =  vtkSmartPointer<vtkTriangle>::New();
    vtkSmartPointer<vtkQuad>                 quadVTK      =  vtkSmartPointer<vtkQuad>::New();
    vtkSmartPointer<vtkTetra>                tetraVTK     =  vtkSmartPointer<vtkTetra>::New();
    vtkSmartPointer<vtkHexahedron>           hexaVTK      =  vtkSmartPointer<vtkHexahedron>::New();

    vtkSmartPointer<vtkQuadraticTriangle>    tria6VTK     =  vtkSmartPointer<vtkQuadraticTriangle>::New();
    vtkSmartPointer<vtkBiQuadraticQuad>      quad9VTK     =  vtkSmartPointer<vtkBiQuadraticQuad>::New();
    vtkSmartPointer<vtkQuadraticTetra>       tetra10VTK   =  vtkSmartPointer<vtkQuadraticTetra>::New();
    //vtkSmartPointer<vtkQuadraticHexahedron>  hexa27VTK    =  vtkSmartPointer<vtkQuadraticHexahedron>::New();

    vtkSmartPointer<vtkFloatArray>           vecVTK       =  vtkSmartPointer<vtkFloatArray>::New();
    vtkSmartPointer<vtkFloatArray>           scaVTK       =  vtkSmartPointer<vtkFloatArray>::New();

    vtkSmartPointer<vtkXMLUnstructuredGridWriter>  writerUGridVTK =  vtkSmartPointer<vtkXMLUnstructuredGridWriter>::New();


    int  ee, ii, jj, kk, nn, n1, n2, npElem;
    double  val, vec[3]={0.0,0.0,0.0}, dsp[3]={0.0,0.0,0.0};

    vecVTK->SetNumberOfTuples(nNode_global_global);
    vecVTK->SetNumberOfComponents(3);
    scaVTK->SetNumberOfTuples(nNode_global_global);

    vecVTK->SetName("Disp");

    vtkIdType pt[10];

    if(ndim == 2)
    {
      for(ii=0; ii<nNode_global_global; ii++)
      {
        pt[0] = pointsVTK->InsertNextPoint(nodeCoordsCur[ii][0], nodeCoordsCur[ii][1], 0.0);

        kk = ii*ndof;

        dsp[0] = SolnData.disp[kk];
        dsp[1] = SolnData.disp[kk+1];

        vecVTK->InsertTuple(ii, dsp);
      }

      for(ee=0; ee<nElem_global_global; ee++)
      {
        npElem = elems[ee]->nodeNums.size();

        if( npElem == 2 )
        {
          for(ii=0; ii<npElem; ii++)
            lineVTK->GetPointIds()->SetId(ii, elems[ee]->nodeNums[ii] );

          uGridVTK->InsertNextCell(lineVTK->GetCellType(), lineVTK->GetPointIds());
        }
        else if(npElem == 3)
        {
          vecVTK->InsertTuple(elemConn[ee][8], vec);

          uGridVTK->InsertNextCell(quad9VTK->GetCellType(), quad9VTK->GetPointIds());
        }
      }
    }
    else // (ndim == 3)
    {
      for(ii=0; ii<nNode_global_global; ii++)
      {
        pt[0] = pointsVTK->InsertNextPoint(nodeCoordsOrig[ii][0], nodeCoordsOrig[ii][1], nodeCoordsOrig[ii][2]);
      }

      for(ee=0; ee<nElem_global_global; ee++)
      {
        npElem = elemConn[ee].size();
      }
    }

    uGridVTK->SetPoints(pointsVTK);
    //uGridVTK->GetPointData()->SetScalars(scaVTK);
    uGridVTK->GetPointData()->SetVectors(vecVTK);

    //Write the file.

    char VTKfilename[200];

    sprintf(VTKfilename,"%s%s%06d%s", dirname.c_str(), "-solid-",fileCount,".vtu");

    writerUGridVTK->SetFileName(VTKfilename);

    writerUGridVTK->SetInputData(uGridVTK);
    writerUGridVTK->Write();

    fileCount = fileCount+1;

    return 0;
}
*/
