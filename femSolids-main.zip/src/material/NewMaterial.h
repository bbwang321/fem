
#ifndef  incl_newMaterial_h
#define  incl_newMaterial_h

#include "MaterialBase.h"

#include "Matl_LinearElastic.h"
#include "Matl_SaintVenantKirchhoff.h"
#include "Matl_NeoHookean.h"
#include "Matl_MooneyRivlin.h"
#include "Matl_Gent.h"
#include "Matl_ArrudaBoyce.h"
#include "Matl_LinearElastic_Viscoelastic.h"
#include "Matl_NeoHookean_Viscoelastic.h"
#include "Matl_MooneyRivlin_Viscoelastic.h"
#include "Matl_Gent_Viscoelastic.h"
#include "Matl_Longevin8chain_Viscoelastic.h"


inline  MaterialBase*  NewMaterial(int type)
{
  cout << "type = " << type << endl;
  switch (type)
  {
    case    1: return (MaterialBase*) new Matl_LinearElastic; break;

    case    2: return (MaterialBase*) new Matl_SaintVenantKirchhoff; break;

    case    3: return (MaterialBase*) new Matl_NeoHookean; break;

    case    4: return (MaterialBase*) new Matl_MooneyRivlin; break;

    case    5: return (MaterialBase*) new Matl_Gent; break;

    case    6: return (MaterialBase*) new Matl_ArrudaBoyce; break;


    case    101: return (MaterialBase*) new Matl_LinearElastic_Viscoelastic; break;

    case    103: return (MaterialBase*) new Matl_NeoHookean_Viscoelastic; break;

    case    104: return (MaterialBase*) new Matl_MooneyRivlin_Viscoelastic; break;

    case    105: return (MaterialBase*) new Matl_Gent_Viscoelastic; break;

    case    106: return (MaterialBase*) new Matl_Longevin8chain_Viscoelastic; break;

    default:
      cerr << " unknown material type name in  NewMaterial..." << endl;
      return nullptr;
      break;
  }
}


#endif

