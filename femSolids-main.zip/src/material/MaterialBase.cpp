#include "MaterialBase.h"
#include <boost/algorithm/string.hpp>
#include <unordered_map>
#include "util.h"


using namespace std;



MaterialBase::MaterialBase()
{
  matData.resize(100);
  MIXED_ELEMENT = false;

  rho0 = 0.0;

  timeIntegrationScheme = "STEADY";
  spectralRadius = 0.0;
  td.resize(100);
  td.setZero();
}





MaterialBase::~MaterialBase()
{
}




void MaterialBase::printData()
{

    return;
}





int MaterialBase::readData(ifstream& infile, string& line)
{
    vector<string>  stringlist;

    unordered_map<string,int>   map_keys = {
                        {"density",                1},
                        {"data",                   2},
                        {"data_deviatoric",        3},
                        {"data_volumetric",        4},
                        {"data_viscoelastic",      5},
                        {"data_elecfield",         6},
                        {"data_magnfield",         7},
                        {"resi_magnfield",         8},
                        {"appl_magnfield",         9},
                        {"tis",                   10},
                        };

    //getline(infile,line);    boost::trim(line);

    int ii = 0;

    while( infile && (line != "}") )
    {
        getline(infile,line);    boost::trim(line);

        if(line[0] == '}') break;

        if( isAValidLine(line) )
        {
            boost::algorithm::split(stringlist, line, boost::is_any_of(":"), boost::token_compress_on);
            for(auto& str: stringlist)  boost::trim(str);

            unordered_map<string,int>::const_iterator got = map_keys.find(stringlist[0]);

            if( got == map_keys.end() )
            {
                throw runtime_error("Key not found in MaterialBase::readInput ...");
                //return -1;
            }

            cout << " got->first  = " << got->first  << endl;
            cout << " got->second = " << got->second << endl;

            switch(got->second)
            {
                case 1:                                     // density

                    rho0 = stod(stringlist[1]);

                break;

                case 2:                                     // data_deviatoric

                    line = stringlist[1];
                    boost::algorithm::split(stringlist, line, boost::is_any_of(" "), boost::token_compress_on);

                    matData.resize(stringlist.size());

                    ii = 0;
                    for(auto& str: stringlist)
                    {
                        boost::trim(str);
                        matData[ii++] = stod(str);
                    }

                    printVector(matData);

                break;

                case 3:                                     // data_deviatoric

                    line = stringlist[1];
                    boost::algorithm::split(stringlist, line, boost::is_any_of(" "), boost::token_compress_on);

                    data_deviatoric.resize(stringlist.size());

                    ii = 0;
                    for(auto& str: stringlist)
                    {
                        boost::trim(str);
                        data_deviatoric[ii++] = stod(str);
                    }

                    printVector(data_deviatoric);

                break;

                case 4:                                     // data_volumetric

                    line = stringlist[1];
                    boost::algorithm::split(stringlist, line, boost::is_any_of(" "), boost::token_compress_on);
                    for(auto& str: stringlist)  boost::trim(str);

                    Utype = stoi(stringlist[0]);

                    Kinv  = stod(stringlist[1]);

                break;

                case 5:                                     // data_viscoelastic

                    line = stringlist[1];
                    boost::algorithm::split(stringlist, line, boost::is_any_of(" "), boost::token_compress_on);

                    data_viscoelastic.resize(stringlist.size());

                    ii = 0;
                    for(auto& str: stringlist)
                    {
                        boost::trim(str);
                        data_viscoelastic[ii++] = stod(str);
                    }

                    printVector(data_viscoelastic);

                break;

                case 10:                                     // time integration scheme

                    timeIntegrationScheme = stringlist[1];

                break;

                default:

                break;

            }
        }
    }

    return 0;
}


