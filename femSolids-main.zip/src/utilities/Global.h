
#ifndef incl_Global_h
#define incl_Global_h


#include "MyTime.h"
#include "TimeFunction.h"
#include <vector>
#include <memory>


MyTime myTime;

std::vector<unique_ptr<TimeFunction> > timeFunction;

bool debug = false;


#endif



