#include "ElementTypeData.h"
#include <boost/algorithm/string.hpp>
#include <unordered_map>
#include <fstream>
#include "utilitiesmaterial.h"
#include "util.h"


ElementTypeData::ElementTypeData()
{
    NLGEOM = false;
}



ElementTypeData::~ElementTypeData()
{
}


int ElementTypeData::readData(ifstream& infile, string& line)
{
    vector<string>  stringlist;

    // read {
    getline(infile,line);    boost::trim(line);

    cout << line << endl;

    while( infile && (line != "}") )
    {
        getline(infile,line);    boost::trim(line);

        cout << line << endl;

        if(line[0] == '}')
        {
            getline(infile,line);
            break;
        }


        if( isAValidLine(line) )
        {
            boost::algorithm::split(stringlist, line, boost::is_any_of(":"), boost::token_compress_on);
            for(auto& str: stringlist)  boost::trim(str);

            if(stringlist[0] == "id")
            {
                id = stoi(stringlist[1]);
            }
            else if(stringlist[0] == "type")
            {
                elemName = stringlist[1];
                
                elemTypeNameNum = getElementID_Standard(elemName);
            }
            else if( (stringlist[0] == "nlgeom") || (stringlist[0] == "NLGEOM") )
            {
                NLGEOM = ( (stringlist[1] == "ON") || (stringlist[1] == "1") );
            }
            else if(stringlist[0] == "data")
            {
                boost::algorithm::split(stringlist, stringlist[1], boost::is_any_of(" "), boost::token_compress_on);
                for(auto& str: stringlist)  boost::trim(str);

                for(int i=0; i<stringlist.size(); i++)
                  elemData.push_back(stod(stringlist[i]));
                
                printVector(elemData);
            }
            else
            {
                throw runtime_error("Option not available in ElementTypeData::readData");
            }
        }
    }

    return 0;
}


