
#ifndef  incl_Domain_h
#define  incl_Domain_h

#include <vector>
#include <iostream>
#include <string>
#include <fstream>


using namespace std;


class Domain
{
public:

    string  label;
    int     matId, elemId, ndim, ndof, tag;

    Domain();

    Domain(string& label_, int tag_, int ndim_);

    ~Domain();

    string  getLabel()
    { return  label;}
    
    int  getTag()
    { return  tag;}

    int readData(ifstream& infile, string& line);
};


#endif
