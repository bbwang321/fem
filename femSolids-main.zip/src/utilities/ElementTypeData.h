#ifndef incl_ElementTypeData_h
#define incl_ElementTypeData_h

#include <vector>
#include <iostream>

using namespace std;



class ElementTypeData
{
  private:

    //member variables
    int             id, elemTypeNameNum;
    bool            NLGEOM;
    string          elemName;
    vector<double>  elemData;

  public:
    //member functions

    ElementTypeData();

    virtual ~ElementTypeData();

    int  getId()
    { return id; }

    int  getElemTypeNameNum()
    { return elemTypeNameNum; }

    bool getNonlinearGeomFlag()
    {
      return NLGEOM;
    }

    void setNonlinearGeomFlag(bool nlg)
    {
      NLGEOM = nlg;
      return;
    }

    string  getElementName()
    { return elemName; }

    vector<double>  getData()
    { return  elemData; }

    int readData(ifstream& infile, string& line);

};

#endif

