
#ifndef incl_SolutionDataSolid_h
#define incl_SolutionDataSolid_h

#include "headersBasic.h"
#include <Eigen/Dense>


using namespace Eigen;


class  SolutionDataSolid
{
  private:
    int  size1, size2, size3, size4, size5;

  public:

    string  timeIntegrationScheme;
    bool firstIter, TRULY_INCOMPRESSIBLE, MassLumping;
    int  timeStepCount;
    double  spectralRadius;

    VectorXd  td, rhsVec, reac, soln, ForceVectorExternal;
    VectorXd  totalForce, totalMoment, centroid;
    VectorXd  disp, dispPrev, dispPrev2, dispCur, dispIncr, dispApplied, dispInit;
    VectorXd  dispDot, dispDotPrev, dispDotPrev2;
    VectorXd  velo, veloPrev, veloPrev2, veloCur, veloInit;
    VectorXd  acce, accePrev, accePrev2, acceCur, acceInit;
    VectorXd  pres, presPrev, presPrev2, presCur, presIncr, presInit, presApplied;
    VectorXd  force, forcePrev, forcePrev2, forceCur;
    VectorXd  dispTarget;

    vector<int>  node_map_new_to_old;
    vector<int>  node_map_old_to_new;


    SolutionDataSolid();

    ~SolutionDataSolid(){}

    void setTimeIncrementType(string ttt);

    void setSpectralRadius(double ttt);

    void  printSelf();

    void  initialise(int size1=0, int size2=0, int size3=0, int size4=0);

    void  setTimeParam();

    void  timeUpdate();

    void  updateIterStep();

    void  reset();

    void  saveSolution();
};





#endif


