
#ifndef incl_headersBasic_h
#define incl_headersBasic_h


#include <iostream>
#include <limits.h>
#include <float.h>
#include <vector>
#include <assert.h>
#include <math.h>
#include <cmath>
#include <stdio.h>
#include <set>
#include <fstream>
#include <string.h>
#include <iomanip>
#include <stdlib.h>
#include <algorithm>
#include <memory>
#include <stdexcept>
#include <string>

#include <numeric>
#include <iterator>
#include <functional>

using namespace std;

using std::vector;
using std::string;

typedef  vector<int>  vecIntSTL;
typedef  vector<float>  vecFltSTL;
typedef  vector<double>  vecDblSTL;


enum  PhysicsType  {PHYSICS_TYPE_FLUID=0, PHYSICS_TYPE_SOLID=1};

enum  SolverLibrary  {SOLVER_LIB_EIGEN=0, SOLVER_LIB_EIGEN_PARDISO=1, SOLVER_LIB_PETSC=2, SOLVER_LIB_PETSC_PARDISO=3};

enum  SolverType  {SOLVER_TYPE_NEWTONRAPHSON=0, SOLVER_TYPE_ARCLENGTH=1, SOLVER_TYPE_DEFLATION=2};

enum  FemModelBehaviour  {PSTRESS=1, PSTRAIN=2, AXISYM=3};

enum MeshConfiguration
{
  CONFIG_ORIGINAL=0, CONFIG_DEFORMED=1
};


enum ElementShape
{
  ELEM_SHAPE_TRIA=1, ELEM_SHAPE_QUAD=2, 
  ELEM_SHAPE_TETRA=4, ELEM_SHAPE_PYRAMID=5, ELEM_SHAPE_WEDGE=6, ELEM_SHAPE_HEXA=8,
  ELEM_TRIA_P2bP1dc = 21
};


struct NodalBC
{
    int     nodeNum;
    int     dof;
    double  value;
    int     timeFuncNum;
    int     spaceFuncNum;
};


struct NodalForce
{
    int     nodeNum;
    int     dof;
    double  value;
    int     timeFuncNum;
};



enum TimeStepType
{
  EXPLICIT = 0, SEMI_IMPLICIT = 1, FULL_IMPLICIT = 2
};



enum ElemTypeNum
{
    ELEM_DUMMY           = -1,

    // 2D Solid elements
    ELEM_SOLID_2D_TRIA3  = 1,
    ELEM_SOLID_2D_QUAD4  = 2,
    ELEM_SOLID_2D_TRIA6  = 3,
    ELEM_SOLID_2D_QUAD8  = 4,
    ELEM_SOLID_2D_QUAD9  = 5,

    // 3D Solid elements
    ELEM_SOLID_3D_TETR4  = 21,
    ELEM_SOLID_3D_PYRM5  = 22,
    ELEM_SOLID_3D_WEDG6  = 23,
    ELEM_SOLID_3D_HEXA8  = 24,
    ELEM_SOLID_3D_TETR10 = 25,
    ELEM_SOLID_3D_PYRM13 = 26,
    ELEM_SOLID_3D_PYRM14 = 27,
    ELEM_SOLID_3D_WEDG15 = 28,
    ELEM_SOLID_3D_WEDG18 = 29,
    ELEM_SOLID_3D_HEXA20 = 30,
    ELEM_SOLID_3D_HEXA27 = 31,

    // 2D truss and beam elements
    ELEM_TRUSS_2D_NODES2 = 61,
    ELEM_BEAM_2D_NODES2  = 62,
    ELEM_BEAM_2D_NODES3  = 63,

    // 3D truss and beam elements
    ELEM_TRUSS_3D_NODES2 = 81,
    ELEM_BEAM_3D_NODES2  = 82,
    ELEM_BEAM_3D_NODES3  = 83,

    ELEM_SHELL_FLAT_QUAD4  = 101,
    ELEM_SHELL_FLAT_TRIA6  = 102,
    ELEM_SHELL_FLAT_QUAD9  = 103
};



#endif


