
#ifndef incl_TimeFunction_h
#define incl_TimeFunction_h


#include <vector>


class TimeFunction
{
  private:
    int id;

  public:

    int  nblocks;

    double tol = 1.e-14, factor;

    std::vector<double>  t0, tf;

    std::vector<std::vector<double> >  ps; // coefficients


    TimeFunction();

    ~TimeFunction();

    void setID(int id_)
    {
        id = id_; return;
    }

    void addTimeBlock(std::vector<double> & ps);

    void update();

    double eval(int i, double tcur=0.0);

    double evalFirstDerivative(int i, double tcur=0.0);

    double evalSecondDerivative(int i, double tcur=0.0);

    void printSelf();
    
    double getFactor()
    {
        return factor;
    }

  private:

};


#endif

