
#include <algorithm>
#include <chrono>
#include "femSolids.h"
#include "util.h"
#include <boost/algorithm/string.hpp>
#include <unordered_map>
#include <unistd.h>
#include "MyTime.h"
#include "TimeFunction.h"
#include "utilitiesmaterial.h"
#include "NewMaterial.h"
#include "utilitiesmaterial.h"
#include "NewLagrangeElement.h"
#include "QuadratureUtil.h"
#include "BasisFunctionsLagrange.h"



using namespace std;

extern  std::vector<unique_ptr<TimeFunction> > timeFunction;
extern  MyTime           myTime;
extern  bool  debug;


femSolids::femSolids()
{
    MPI_Comm_size(MPI_COMM_WORLD, &n_mpi_procs);
    MPI_Comm_rank(MPI_COMM_WORLD, &this_mpi_proc);

    nNode_owned  = 0;
    nElem_global = 0;
    nNode_global = 0;
    fileCount = 0;
    ndof = 0;
    
    numElemTypes = 0;
    numMaterials = 0;

    dispDOF = 0;
    presDOF = 0;
    totalDOF = 0;

    intVarFlag = false;
    IMPLICIT_SOLVER = true;
    MIXED_ELEMENT = false;
    convergedFlagPrev = convergedFlag = false;


    loadStepConverged = 0;
    loadFactor = 0.0;
    loadFactorPrev = 0.0;
    loadFactorPrev2 = 0.0;
    loadfactorVec.push_back(loadFactor);

    localStiffnessError = 0;

    NONLINEAR_SOLVER_TYPE = SOLVER_TYPE_NEWTONRAPHSON;

    AlgoType = 2;

    conv_tol = 1.0e-6;

    elems = nullptr;

    dirname = get_current_dir_name();
    vector<string> stringlist;
    boost::algorithm::split(stringlist, dirname, boost::is_any_of("/"), boost::token_compress_on);
    for(auto& str: stringlist)  boost::trim(str);

    dirname = stringlist[stringlist.size()-1];
}


femSolids::~femSolids()
{
  if(elems != NULL)
  {
    for(int ii=0;ii<nElem_global;ii++)
      delete elems[ii];

    delete [] elems;
    elems = NULL;
  }
}




int  femSolids::deallocatePetscObjects()
{
  solverPetsc->free();

  return 0;
}




int  femSolids::readInputMine(ifstream& infile)
{
    cout << " femSolids::readInput " << endl;

    string line;
    vector<string>  stringlist;

    while(getline(infile,line))
    {
        //if (line == "") continue;
        boost::trim(line);

        //std::cout << line << std::endl;

        if( isAValidLine(line) )
        {
            //std::cout << line << std::endl;

            if(line.compare(string("Model Type")) == 0)
            {
                cout << "Model Type" << endl;
                readModelType(infile, line);
            }
            else if( (line.compare(string("Nodes")) == 0) || (line.compare(string("nodes")) == 0) )
            {
                cout << "Nodes" << endl;
                readNodes(infile, line);
            }
            else if( (line.compare(string("Elements")) == 0) || (line.compare(string("elements")) == 0) )
            {
                cout << "Elements" << endl;
                readSolidElements(infile, line);
            }
            else if( (line.compare(string("Prescribed Boundary Conditions")) == 0) || (line.compare(string("prescribed boundary conditions")) == 0) )
            {
                cout << "Prescribed Boundary Conditions" << endl;
                this->readPrescribedBCs(infile, line);
            }
            else if(line.compare(string("Face Load Elements")) == 0)
            {
                cout << "Face Load Elements" << endl;
                readSurfaceElements(infile, line);
            }
            else if( (line.compare(string("Nodal Forces")) == 0) || (line.compare(string("nodal forces")) == 0) )
            {
                cout << "Nodal Forces" << endl;
                readNodalForces(infile, line);
            }
            else if(line.compare(string("Element")) == 0)
            {
                cout << "Element Type" << endl;
                readElementProps(infile, line);
            }
            else if(line.compare(string("Material")) == 0)
            {
                cout << "Material Type" << endl;
                readMaterialProps(infile, line);
            }
            else if(line.compare(string("Body Force")) == 0)
            {
                cout << "Body Force" << endl;
                readBodyForce(infile, line);
            }
            else if(line.compare(string("Time Function")) == 0)
            {
                cout << "Time Function" << endl;
                readTimeFunctions(infile, line);
            }
            else if(line.compare(string("Solver")) == 0)
            {
                cout << "Solver" << endl;
                readSolverDetails(infile, line);
            }
            else if(line.compare(string("Nodal Data Output")) == 0)
            {
                cout << "Output" << endl;
                readNodalDataForOutput(infile, line);
            }
            else if(line.compare(string("Output")) == 0)
            {
                cout << "Output" << endl;
                readOutputDetails(infile, line);

                //printVector(outputlist_nodal);
                //printVector(outputlist_elemental);
            }
            else
            {
                cout << "key =  " <<  line << endl;
                throw runtime_error("Key not found in femSolids::readInput ...");
                //return -1;
            }

      }
    }

    infile.close();

    cout << " Input file is successfully read " << endl;

    return 0;
}







int femSolids::readConfiguration(string& fname)
{
    cout << " femSolids::readConfiguration " << endl;

    ifstream  infile(fname);

    if(infile.fail())
    {
       cout << " Could not open input file " << endl;
       exit(-1);
    }


    string line;
    vector<string>  stringlist;

    while(getline(infile,line))
    {
        boost::trim(line);
 
        //cout << " size       = " << line.size() << endl;
        //cout << " first word = " << line[0] << endl;

        if( isAValidLine(line) )
        {
            //std::cout << line << std::endl;

            if(line.compare(string("files")) == 0)
            {
                cout << "files" << endl;
                // read the files
                //readInputFiles(infile, line);
            }
            else if(line.compare(string("Material")) == 0)
            {
                cout << "Material" << endl;
                readMaterialProps(infile, line);
            }
            else if(line.compare(string("Element")) == 0)
            {
                cout << "Element" << endl;
                readElementProps(infile, line);
            }
            else if(line.compare(string("Body Force")) == 0)
            {
                cout << "Body Force" << endl;
                readBodyForce(infile, line);
            }
            else if(line.compare(string("Time Functions")) == 0)
            {
                cout << "Time Functions" << endl;
                readTimeFunctions(infile, line);
            }
            else if(line.compare(string("Solver")) == 0)
            {
                cout << "Solver" << endl;
                readSolverDetails(infile, line);
            }
            else if(line.compare(string("Initial Conditions")) == 0)
            {
                cout << "Initial Conditions" << endl;
                readInitialConditions(infile, line);
            }
            else if(line.compare(string("Nodal Forces")) == 0)
            {
                cout << "Nodal Forces" << endl;
                readNodalForces(infile, line);
            }
            else if(line.compare(string("Output")) == 0)
            {
                cout << "Output" << endl;
                //readOutputDetails(infile, line);
            }
            else
            {
                cout << "key =  " <<  line << endl;
                throw runtime_error("Key not found in femSolids::readConfiguration ...");
                //return -1;
            }
      }
    }

    infile.close();

    cout << " Configuration file is successfully read " << endl;

    return 0;
}





int  femSolids::readModelType(ifstream& infile, string& line)
{
    vector<string>  stringlist;

    // read {
    getline(infile,line);    boost::trim(line);

    cout << line << endl;

    while( infile && (line != "}") )
    {
        getline(infile,line);    boost::trim(line);

        if(line[0] == '}') break;


        if( isAValidLine(line) )
        {
            boost::algorithm::split(stringlist, line, boost::is_any_of(":"), boost::token_compress_on);
            for(auto& str: stringlist)  boost::trim(str);

            if(stringlist[0] == "dimension")
            {
                ndim = stoi(stringlist[1]);

                assert( (ndim > 0) && (ndim < 4) );

                ndof = ndim;
            }
            else if(stringlist[0] == "behaviour")
            {
                if( (stringlist[1] == "pstress") || (stringlist[1] == "PSTRESS") )
                  GeomData.setModelBehaviour(PSTRESS);
                else if ( (stringlist[1] == "pstrain") || (stringlist[1] == "PSTRAIN") )
                  GeomData.setModelBehaviour(PSTRAIN);
                else if ( (stringlist[1] == "axisym") || (stringlist[1] == "AXISYM") )
                  GeomData.setModelBehaviour(AXISYM);
                else
                {
                  throw runtime_error("Behaviour type not available in femSolids::readModelType");
                }
            }
            else if(stringlist[0] == "thickness")
            {
                GeomData.setThicnkess(stod(stringlist[1]));
            }
            else
            {
                throw runtime_error("Option not available in femSolids::readModelType");
            }
        }
    }

    return 0;
}





int  femSolids::readNodes(ifstream& infile, string& line)
{
    vector<string>  stringlist;

    // read the number of nodes
    getline(infile,line);    boost::trim(line);

    nNode_global = stoi(line);

    cout << "nNode_global = " << nNode_global << endl;
    cout << "ndim = " << ndim << endl;

    vector<myPoint>  nodePosData;
    nodePosData.resize(nNode_global);

    for(int ii=0; ii<nNode_global; ii++)
    {
        getline(infile,line);        boost::trim(line);

        boost::algorithm::split(stringlist, line, boost::is_any_of("\t "), boost::token_compress_on);
        for(auto& str: stringlist)  boost::trim(str);

        nodePosData[ii][0] = stod(stringlist[1]);
        nodePosData[ii][1] = stod(stringlist[2]);
        if(ndim == 3) nodePosData[ii][2] = stod(stringlist[3]);
    }

    GeomData.setDimension(ndim);
    GeomData.setNodalPositions(nodePosData);

    return 0;
}





int  femSolids::readSolidElements(ifstream& infile, string& line)
{
    // read the number of elements
    getline(infile,line);    boost::trim(line);

    nElem_global = stoi(line);

    cout << "nElem_global = " << nElem_global << endl;

    vector<string>  stringlist;

    elemConn.resize(nElem_global);

    for(int ee=0; ee<nElem_global; ee++)
    {
        getline(infile,line);
        boost::trim(line);
        //cout << line << endl;
        boost::algorithm::split(stringlist, line, boost::is_any_of("\t "), boost::token_compress_on);
        //stringlist.erase(std::remove(stringlist.begin(), stringlist.end(), " "), stringlist.end());


        int ind = stringlist.size();
        //cout << "ind = " << ind << endl;

        elemConn[ee].resize(ind-1);

        for(int j=1; j<ind; j++)
            elemConn[ee][j-1] = stoi(stringlist[j]) - 1;

        //printVector(elemConn[ee]);
    }

    return 0;
}



int  femSolids::readSurfaceElements(ifstream& infile, string& line)
{
    // read the number of elements
    getline(infile,line);    boost::trim(line);
/*
    nElemFaces = stoi(line);

    cout << "nElemFaces = " << nElemFaces << endl;

    vector<string>  stringlist;

    elemConnFaces.resize(nElemFaces);

    for(int ee=0; ee<nElemFaces; ee++)
    {
        getline(infile,line);
        boost::trim(line);
        //cout << line << endl;
        boost::algorithm::split(stringlist, line, boost::is_any_of("\t "), boost::token_compress_on);
        //stringlist.erase(std::remove(stringlist.begin(), stringlist.end(), " "), stringlist.end());


        int ind = stringlist.size();
        //cout << "ind = " << ind << endl;

        elemConnFaces[ee].resize(ind-1);

        for(int j=1; j<ind; j++)
            elemConnFaces[ee][j-1] = stoi(stringlist[j]) - 1;

        //printVector(elemConnFaces[ee]);
    }
*/
    return 0;
}



int  femSolids::readPrescribedBCs(ifstream& infile, string& line)
{
    // read the number of prescribed BCs
    getline(infile,line);    boost::trim(line);

    int nDBC = stoi(line), count;
    vector<string>  stringlist;

    cout << "nDBC = " << nDBC << endl;

    NodalBCs.resize(nDBC);
    for(int ee=0; ee<nDBC; ee++)
    {
        getline(infile,line);
        boost::trim(line);
        boost::algorithm::split(stringlist, line, boost::is_any_of("\t "), boost::token_compress_on);
        for(auto& str: stringlist)  boost::trim(str);

        count = stringlist.size();
        if(count < 3)
        {
            cerr << "Input error in 'prescribed boundary conditions' !" << endl;
        }


        NodalBCs[ee].nodeNum      = stoi(stringlist[0])-1 ;
        NodalBCs[ee].dof          = stoi(stringlist[1])-1 ;
        NodalBCs[ee].value        = stod(stringlist[2]) ;
        NodalBCs[ee].timeFuncNum  = -1;
        NodalBCs[ee].spaceFuncNum = -1;

        if(count >= 4)
          NodalBCs[ee].timeFuncNum  = stoi(stringlist[3])-1 ;

        if(count >= 5)
          NodalBCs[ee].spaceFuncNum = stoi(stringlist[4])-1 ;
    }

    return 0;
}





int  femSolids::readNodalForces(ifstream& infile, string& line)
{
    // read the number of nodal forces
    getline(infile,line);    boost::trim(line);

    int  nFBC = stoi(line), count;
    vector<string>  stringlist;

    cout << "nFBC = " << nFBC << endl;

    NodalForces.resize(nFBC);
    for(int ee=0; ee<nFBC; ee++)
    {
        getline(infile,line);
        boost::trim(line);
        boost::algorithm::split(stringlist, line, boost::is_any_of("\t "), boost::token_compress_on);
        for(auto& str: stringlist)  boost::trim(str);

        count = stringlist.size();
        if(count < 3)
        {
            cerr << "Input error in 'nodal forces' !" << endl;
        }


        NodalForces[ee].nodeNum      = stoi(stringlist[0])-1 ;
        NodalForces[ee].dof          = stoi(stringlist[1])-1 ;
        NodalForces[ee].value        = stod(stringlist[2]) ;
        NodalForces[ee].timeFuncNum  = -1;

        if(count >= 4)
          NodalForces[ee].timeFuncNum  = stoi(stringlist[3])-1 ;
    }

    return 0;
}






int femSolids::readMaterialProps(ifstream& infile, string& line)
{

    // read {
    getline(infile,line);    boost::trim(line);

    // read id
    getline(infile,line);    boost::trim(line);

    vector<string>  stringlist;
    boost::algorithm::split(stringlist, line, boost::is_any_of(":"), boost::token_compress_on);
    for(auto& str: stringlist)  boost::trim(str);

    int  id = stoi(stringlist[1]);

    // read name
    getline(infile,line);    boost::trim(line);
    boost::algorithm::split(stringlist, line, boost::is_any_of(":"), boost::token_compress_on);
    for(auto& str: stringlist)  boost::trim(str);


    std::string matkey(stringlist[1]);

    int  idd = getMaterialID(matkey);

    cout << " idd = " << idd << endl;

    if( (idd == 101) || (idd == 102) || (idd == 103) || (idd == 2006) || (idd == 2007) )
      intVarFlag = true;

    MatlDataList.push_back( NewMaterial(idd) );

    MatlDataList[numMaterials]->setID(id);

    MatlDataList[numMaterials]->SolnData = &(SolnData);

    MatlDataList[numMaterials]->readData(infile, line);

    numMaterials++;

    cout << "numMaterials = " << numMaterials << endl;

    return 0;
}





int femSolids::readElementProps(ifstream& infile, string& line)
{
    cout <<  " femSolids::readElementProps ... " << endl;

    ElementTypeDataList.push_back( new ElementTypeData );

    ElementTypeDataList[numElemTypes]->readData(infile, line);

    numElemTypes++;

    cout << "numElemTypes = " << numElemTypes << endl;

    cout <<  " femSolids::readElementProps ... " << endl;

    return 0;
}





int  femSolids::readBodyForce(ifstream& infile, string& line)
{
    vector<string>  stringlist;
    myPoint  bforce;

    // read {
    getline(infile,line);    boost::trim(line);

    while( infile && (line != "}") )
    {
        getline(infile,line);    boost::trim(line);

        if(line[0] == '}') break;

        if( isAValidLine(line) )
        {
            boost::algorithm::split(stringlist, line, boost::is_any_of(":"), boost::token_compress_on);
            for(auto& str: stringlist)  boost::trim(str);

            if(stringlist[0] == "value")
            {
                boost::algorithm::split(stringlist, stringlist[1], boost::is_any_of("\t "), boost::token_compress_on);
                for(auto& str: stringlist)  boost::trim(str);

                bforce[0] = stod(stringlist[0]);
                bforce[1] = stod(stringlist[1]);
                bforce[2] = stod(stringlist[2]);

                GeomData.setBodyForce(bforce);
            }
            else if( (stringlist[0] == "timefunction") || (stringlist[0] == "TimeFunction") )
            {
                GeomData.setBodyForceTimeFunction( stoi(stringlist[1])-1 );
            }
            else
            {
                throw runtime_error("Option not available in femSolids::readBodyForce");
            }
        }
    }


    return 0;
}



int  femSolids::readSolverDetails(ifstream& infile, string& line)
{
    vector<string>  stringlist;

    // read {
    getline(infile,line);    boost::trim(line);

    while( infile && (line != "}") )
    {
        getline(infile,line);    boost::trim(line);

        if(line[0] == '}') break;


        if( isAValidLine(line) )
        {
            boost::algorithm::split(stringlist, line, boost::is_any_of(":"), boost::token_compress_on);
            for(auto& str: stringlist)  boost::trim(str);

            if(stringlist[0] == "solvertype")
            {
                if(stringlist[1] == "arclength")
                {
                  NONLINEAR_SOLVER_TYPE = SOLVER_TYPE_ARCLENGTH;
                  ARC_LENGTH = true;
                }
                else
                  NONLINEAR_SOLVER_TYPE = SOLVER_TYPE_NEWTONRAPHSON;
            }
            else if(stringlist[1] == "formulation")
            {
            }
            else if(stringlist[0] == "timescheme")
            {
                SolnData.timeIntegrationScheme = stringlist[1];
            }
            else if(stringlist[0] == "spectralRadius")
            {
                SolnData.spectralRadius = stod(stringlist[1]);
            }
            else if(stringlist[0] == "finalTime")
            {
                timeFinal = stod(stringlist[1]);
            }
            else if(stringlist[0] == "timeStep")
            {
                boost::algorithm::split(stringlist, stringlist[1], boost::is_any_of("\t "), boost::token_compress_on);
                for(auto& str: stringlist)  boost::trim(str);

                if(stringlist.size() == 1)
                {
                    myTime.set( stod(stringlist[0]), stod(stringlist[0]), stod(stringlist[0]) );
                }
                else if(stringlist.size() == 2)
                {
                    myTime.set( stod(stringlist[0]), stod(stringlist[1]), stod(stringlist[0]) );
                }
                else
                {
                    myTime.set( stod(stringlist[0]), stod(stringlist[1]), stod(stringlist[2]) );
                }
            }
            else if(stringlist[0] == "maximumSteps")
            {
                stepsMax = stoi(stringlist[1]);
            }
            else if(stringlist[0] == "maximumIterations")
            {
                iterationsMax = stoi(stringlist[1]);
            }
            else if(stringlist[0] == "tolerance")
            {
                conv_tol = stod(stringlist[1]);
            }
            else if(stringlist[0] == "debug")
            {
                debug = ( stoi(stringlist[1]) == 1);
            }
            else if(stringlist[0] == "outputFrequency")
            {
                outputFreq = stoi(stringlist[1]);
            }
            else
            {
                throw runtime_error("Option not available in femSolids::readSolverDetails");
            }
        }
    }


    return 0;
}



int  femSolids::readTimeFunctions(ifstream& infile, string& line)
{
    // read {
    //getline(infile,line);    boost::trim(line);
    //prgReadTimeFunctions(infile);

    vector<string>  stringlist;
    vector<double>  doublelist;

    // read {
    getline(infile,line);    boost::trim(line);

    while( infile && (line != "}") )
    {
        getline(infile,line);    boost::trim(line);

        cout << line << endl;

        if(line[0] == '}') break;


        if( isAValidLine(line) )
        {
            boost::algorithm::split(stringlist, line, boost::is_any_of("\t "), boost::token_compress_on);
            for(auto& str: stringlist)  boost::trim(str);

            int id = stoi(stringlist[0]);

            if(id == 0)
            {
                cout << " Time function id '0' is not addmissible. It should be 1 or higher. " << endl;
                throw runtime_error(" Error in femSolids::readTimeFunctions...  ");
            }

            if(stringlist.size() < 11)
            {
                cout << " Number of temrs in Time function should be at least 11 " << endl;
                throw runtime_error(" Error in femSolids::readTimeFunctions...  ");
            }

            doublelist.resize(stringlist.size()-1);
            for(int i=0; i<stringlist.size()-1; ++i)
            {
                doublelist[i] = stod(stringlist[i+1]);
            }

            id -= 1;
            if(id == timeFunction.size())
            {
                timeFunction.push_back(make_unique<TimeFunction>());
                timeFunction[id]->setID(id);
            }
            timeFunction[id]->addTimeBlock(doublelist);
        }
    }

    for(auto& tmf : timeFunction)
    {
        tmf->printSelf();
        tmf->update();
    }

    return 0;
}





int femSolids::readInitialConditions(ifstream& infile, string& line)
{
    vector<string>  stringlist;
    string label;

    return 0;
}





int femSolids::readNodalDataForOutput(ifstream& infile, string& line)
{
/*
    // read the number of rows
    getline(infile,line);    boost::trim(line);

    int  nOut = stoi(line);

    vector<string>  stringlist;
    vector<double>  vecTemp(3);

    for(int ee=0; ee<nOut; ee++)
    {
        getline(infile,line);        boost::trim(line);
        boost::algorithm::split(stringlist, line, boost::is_any_of("\t "), boost::token_compress_on);
        //stringlist.erase(std::remove(stringlist.begin(), stringlist.end(), " "), stringlist.end());

        int ind = stringlist.size();
        //cout << "ind = " << ind << endl;

        vecTemp[0] = stod(stringlist[0]);
        vecTemp[1] = stod(stringlist[1]);
        vecTemp[2] = stod(stringlist[2]);

        OutputData.push_back(vecTemp);

        //printVector(DirichletBCs[ee]);
    }
*/
    return 0;
}


int femSolids::readOutputDetails(ifstream& infile, string& line)
{
    vector<string>  stringlist;

    // read {
    getline(infile,line);    boost::trim(line);

    while( infile && (line != "}") )
    {
        getline(infile,line);    boost::trim(line);

        cout << line << endl;

        if(line[0] == '}') break;


        if( isAValidLine(line) )
        {
            boost::algorithm::split(stringlist, line, boost::is_any_of(":"), boost::token_compress_on);
            for(auto& str: stringlist)  boost::trim(str);

            if(stringlist[0] == "Frequency")
            {
                outputfrequency = stoi(stringlist[1]);
            }
            else if(stringlist[0] == "Nodal")
            {
                outputlist_nodal.push_back(stringlist[1]);
            }
            else if(stringlist[0] == "Elemental")
            {
                outputlist_elemental.push_back(stringlist[1]);
            }
            else
            {
                throw runtime_error("Option not available in femSolids::readOutputDetails");
            }
        }
    }

    return 0;
}






int femSolids::prepareInputData()
{
    PetscPrintf(MPI_COMM_WORLD, "\n\n     femSolids::prepareInputData()  .... STARTED ...\n\n");

    assert(ndim > 0 && ndim < 4);

    ndof = ndim;

    int  idd = ElementTypeDataList[0]->getElemTypeNameNum();
    cout << "idd = " << idd << endl;
    if( idd == ELEM_TRUSS_2D_NODES2 )
      ndof = 2;
    else if( idd == ELEM_TRUSS_3D_NODES2 )
      ndof = 3;
    if( (idd == ELEM_BEAM_2D_NODES2) || (idd == ELEM_BEAM_2D_NODES3) )
      ndof = 3;
    if( (idd == ELEM_BEAM_3D_NODES2) || (idd == ELEM_BEAM_3D_NODES3) )
      ndof = 6;
    else if( idd == ELEM_SHELL_FLAT_QUAD4 )
      ndof = 6;

    if(this_mpi_proc == 0)
    {
        cout << " ndim  = " << ndim         << endl;
        cout << " nElem = " << nElem_global << endl;
        cout << " nNode = " << nNode_global << endl;
        cout << " ndof  = " << ndof         << endl;
    }

    // ==================================================
    //
    // Partition the mesh if more than one processor
    //
    // ==================================================

    node_map_get_old.resize(nNode_global, 0);
    node_map_get_new.resize(nNode_global, 0);

    elem_proc_id.resize(nElem_global, 0);
    node_proc_id.resize(nNode_global, 0);

    if(n_mpi_procs == 1)
    {
        elem_start  = 0;
        elem_end    = nElem_global-1;

        node_start  = 0;
        node_end    = nNode_global-1;

        nElem_local = nElem_global;
        nNode_local = nNode_global;
        nNode_owned = nNode_global;

        for(int ii=0; ii<nNode_global; ii++)
        {
          node_map_get_old[ii] = ii;
          node_map_get_new[ii] = ii;
        }
    }
    else
    {
        PetscPrintf(MPI_COMM_WORLD, "\n\n Before partitionMesh ... \n\n");
        PetscPrintf(MPI_COMM_WORLD, "\n\n n_mpi_procs %d ... \n\n", n_mpi_procs);

        partitionMesh();

        PetscPrintf(MPI_COMM_WORLD, "\n\n After partitionMesh ... \n\n"); 
    }

    errpetsc = MPI_Barrier(MPI_COMM_WORLD);


    int ii, jj, kk, ee, nn, ind, n1, n2, dof, tag, index, matId, elemId, npElem;

    // ==================================================
    //
    // Check the  consistency of input data
    //
    // ==================================================

    //checkInputData();

    vector<int>  nodeNums;

    // create elements and prepare element data
    elems = new ElementBase* [nElem_global];

    for(ee=0;ee<nElem_global;++ee)
    {
      npElem = elemConn[ee].size()-3;

      nodeNums.resize(npElem);

      for(ii=0; ii<npElem; ii++)
        nodeNums[ii] = elemConn[ee][3+ii];

      elemId = elemConn[ee][0];
      matId  = elemConn[ee][1];

      elems[ee] = NewLagrangeElement(ElementTypeDataList[elemId]->getElemTypeNameNum());

      elems[ee]->elenum       = ee;
      elems[ee]->nodeNums     = nodeNums;

      elems[ee]->SolnData     = &(SolnData);
      elems[ee]->GeomData     = &(GeomData);
      elems[ee]->MatlData     = MatlDataList[matId];
      elems[ee]->ElemTypeData = ElementTypeDataList[elemId];

      elems[ee]->prepareElemData();
    //}
    }

    PetscPrintf(MPI_COMM_WORLD, "\n elements are created and prepared \n");
    
    ///////////////////////////////////////////////////////////////////
    //
    // set SolnData details
    //
    ///////////////////////////////////////////////////////////////////

    ind = nNode_global*ndof;
    SolnData.initialise(ind, nNode_global, 0, 0);

    PetscPrintf(MPI_COMM_WORLD, "     femSolids::prepareInputData()  .... FINISHED ...\n\n");

    return 0;
}





int femSolids::printInfo()
{
    return 0;
}







int femSolids::setSpecifiedDOFs(vector<vector<bool> >& NodeType)
{
    int  ii, nn, dof;

    dofs_specified.clear();
    for(ii=0; ii<NodalBCs.size(); ii++)
    {
        nn = NodalBCs[ii].nodeNum;
        dof = NodalBCs[ii].dof;

        NodeType[nn][dof] = true;
        dofs_specified.push_back(nn*ndof+dof);
    }
    findUnique(dofs_specified);

    return 0;
}







int femSolids::setBoundaryConditions()
{
    int  ii, nn, dof, timeFuncNum;
    double loadFactor;

    SolnData.dispApplied.setZero();
    //
    for(ii=0; ii<NodalBCs.size(); ii++)
    {
        nn          = NodalBCs[ii].nodeNum;
        dof         = NodalBCs[ii].dof;
        timeFuncNum = NodalBCs[ii].timeFuncNum;

        loadFactor = 1.0;
        if(timeFuncNum >= 0)
          loadFactor = timeFunction[timeFuncNum]->getFactor();

        SolnData.dispApplied[nn*ndof+dof] = NodalBCs[ii].value * loadFactor;
    }
    SolnData.dispApplied -= SolnData.disp;

/*
    // spatially varying boundary conditions
    nn = nodeNums[i];

    xc = GeomData.NodePosOrig[nn][0];
    yc = GeomData.NodePosOrig[nn][1];
    zc = GeomData.NodePosOrig[nn][2];

    value = mathfun.getValue(xc, yc, zc) * loadFactor;
*/

    return 0;
}




int femSolids::addBoundaryConditions()
{
    int ii, ind;
    for(ii=0; ii<NodalBCs.size(); ++ii)
    {
        ind = NodalBCs[ii].nodeNum * ndof + NodalBCs[ii].dof;

        SolnData.disp[ind]  += SolnData.dispApplied[ind];
    }

    return 0;
}







int femSolids::setInitialConditions()
{
    PetscPrintf(MPI_COMM_WORLD, "femSolids::setInitialConditions() ... \n");
/*
    double  x=0.0, y=0.0, z=0.0, eps = 0.02;
    string  expr;

    SolnData.dispPrev.setZero();
    
    for(int dof=0; dof<ndof; ++dof)
    {
      expr = initialConitions[dof];

      cout << expr << endl;

      if( !expr.empty() )
      {
        myMathFunction  mathfun;
        mathfun.initialise(initialConitions[dof]);

        exprtk::expression<double>   expression;

        exprtk::symbol_table<double> symbol_table;
        exprtk::parser<double>       parser;

        symbol_table.add_variable("x",x);
        symbol_table.add_variable("y",y);
        symbol_table.add_variable("z",z);
        symbol_table.add_variable("eps",eps);
        symbol_table.add_constants();
        expression.register_symbol_table(symbol_table);

        parser.compile(expr, expression);

        for(int ii=0; ii<nNode_global; ++ii)
        {
          x = nodeCoordsOrig[ii][0];
          y = nodeCoordsOrig[ii][1];
          z = nodeCoordsOrig[ii][2];

          SolnData.dispPrev(node_map_get_new[ii]*ndof + dof) = expression.value();
        }
      }
    }
    PetscPrintf(MPI_COMM_WORLD, "femSolids::setInitialConditions() ... \n");

    // add boundary Conditions
    //setBoundaryConditions();
    //solnPrev += solnApplied;

    SolnData.disp = SolnData.dispPrev;
*/

    SolnData.velo.setZero();
    SolnData.veloPrev = SolnData.velo;

    PetscPrintf(MPI_COMM_WORLD, "femSolids::setInitialConditions() ... \n");

/*
    double  xx=0.0, yy=0.0, zz=0.0, fact;

    for(int ii=0; ii<nNode; ++ii)
    {
        xx = nodeCoordsOrig[ii][0];
        yy = nodeCoordsOrig[ii][1];
        //zz = nodeCoordsOrig[ii][2];

        //veloPrev(ii*2) = 2.0*yy*(3.0-yy)/3.0;
        SolnData.veloPrev(ii*ndim) = 1.0*yy;

        //veloPrev(ii*ndim) = 16.0*0.45*yy*zz*(0.41-yy)*(0.41-zz)/0.41/0.41/0.41/0.41;
    }
    SolnData.velo = SolnData.veloPrev;
*/

    return 0;
}




int femSolids::addExternalForces()
{
    if(this_mpi_proc > 0) return 0;

    if(debug) {PetscPrintf(MPI_COMM_WORLD, "\n\n femSolids::addExternalForces() ... STARTED \n");}

    solverPetsc->Fext.setZero();

    if(NodalForces.size() > 0)
    {
        int  nn, dof, ii, timeFuncNum;

        for(ii=0;ii<NodalForces.size();ii++)
        {
            nn          = NodalForces[ii].nodeNum;
            dof         = NodalForces[ii].dof;
            timeFuncNum = NodalForces[ii].timeFuncNum;

            loadFactor = 1.0;
            if(timeFuncNum >= 0)
              loadFactor = timeFunction[timeFuncNum]->getFactor();

            solverPetsc->Fext[nn*ndof+dof] += loadFactor*NodalForces[ii].value;
        }
    }

    if(debug) {PetscPrintf(MPI_COMM_WORLD, "\n\n\n femSolids::addExternalForces() ... ENDED \n");}

    return 0;
}






int femSolids::timeUpdate()
{
    if(debug) {PetscPrintf(MPI_COMM_WORLD, " femSolids::timeUpdate() ... STARTED \n");}

    myTime.update();

    // set parameters for the time integration scheme.
    // need to be done every time step to account for adaptive time stepping
    SolnData.setTimeParam();

    int  idd = 0;//SolnData.ElemProp[0]->id;
    if( (idd == 2010) || (idd == 2060) )
    {
        for(int ee=0; ee<nElem_global; ee++)
        {
            elems[ee]->presDOF     = elems[ee]->presDOFprev;
            elems[ee]->presDOFprev = elems[ee]->presDOFprev2;
        }
    }

    // copy internal variables intVar1 to intVar2
    if(intVarFlag)
      copyElemInternalVariables();

    // update time functions
    for(auto& tmf : timeFunction)
      tmf->update();

    // set Dirichlet boundary conditions
    setBoundaryConditions();

    if(debug) {PetscPrintf(MPI_COMM_WORLD, "\n femSolids::timeUpdate() ... FINISHED \n\n"); }

    return 0;
}




int femSolids::updateIterStep()
{
    SolnData.updateIterStep();

    int  ii, jj, ind;
    for(ii=0;ii<nNode_global;ii++)
    {
      for(jj=0;jj<ndim;jj++)
      {
        ind = ii*ndof+jj;

        GeomData.NodePosNew[ii][jj] = GeomData.NodePosOrig[ii][jj] + SolnData.disp[ind];
        GeomData.NodePosCur[ii][jj] = GeomData.NodePosOrig[ii][jj] + SolnData.dispCur[ind];
      }
    }

    return 0;
}




int  femSolids::reset()
{
    SolnData.reset();

    return 0;
}




bool femSolids::converged()
{
  if (rhsNorm < conv_tol)
    return true;

  return false;
}



bool femSolids::diverging(double factor)
{
  if (isnan(rhsNorm)) return true;

  if (rhsNormPrev > -0.1 && (rhsNorm/rhsNormPrev) > factor) return true;

  if (localStiffnessError != 0) return true;

  return false;
}




int  femSolids::saveSolution()
{
    SolnData.saveSolution();

    int  idd = 0.0;//SolnData.ElemProp[0]->id;
    if( (idd == 2010) || (idd == 2060) )
    {
        for(int ee=0; ee<nElem_global; ee++)
        {
            elems[ee]->presDOFprev2 = elems[ee]->presDOFprev;
            elems[ee]->presDOFprev  = elems[ee]->presDOF;
        }
    }

    if(intVarFlag)
    {
        for(int ee=0; ee<nElem_global; ee++)
        {
          elems[ee]->ivar.saveSolution();
        }
    }

    return 0;
}




int  femSolids::copyElemInternalVariables()
{
    return 0;
}





int femSolids::writeNodalData()
{
  return 0;
}





int  femSolids::readInputBDF(ifstream& infile)
{
    cout << " femSolids::readInputBDF " << endl;

    string line, line2;
    vector<string>  stringlist, stringlist2;

    vector<vector<int> >  elemConnTemp;
    vector<myPoint>       nodecoords;
    vector<int>  vecTempInt;
    vector<double>   vecTempDbl;
    myPoint   pt1, pt2;
    
    int  ee, ii, jj, kk;
    
    nNode_global = 0;
    nElem_global = 0;
    ndim = 3;
    ndof = 3;


    while(getline(infile,line))
    {
      //std::cout << line << std::endl;

      boost::algorithm::split(stringlist, line, boost::is_any_of(" "), boost::token_compress_on);
      for(auto& str: stringlist)  boost::trim(str);


      if( (stringlist[0] == "GRID") || (stringlist[0] == "GRID*") )
      {
          if(stringlist[0] == "GRID")
          {
            pt1[0] = stod(stringlist[2]);
            pt1[1] = stod(stringlist[3]);
            pt1[2] = stod(stringlist[4]);
          }
          else
          {
            // 0-7, 8-23, 24-39, 40-55, 56-72

            pt1[0] = stod( line.substr(40,16) );
            pt1[1] = stod( line.substr(56,16) );

            getline(infile,line2);
            pt1[2] = stod( line2.substr(8,16) );
          }

          nodecoords.push_back(pt1);
      }
      //
      //
      else if(stringlist[0] == "CQUAD4")
      {
        ndim = 2;
        ndof = 2;
        //cout << " size = " << stringlist.size() << endl;

        vecTempInt.clear();

        for(ii=0; ii<stringlist.size()-1; ii++)
        {
            vecTempInt.push_back( stoi(stringlist[1+ii]) );
        }

        elemConn.push_back(vecTempInt);
      }
      //
      //
      else if(stringlist[0] == "MAT1") // Isotropic linear elastic material
      {
          MatlDataList.push_back( NewMaterial(1) );

          MatlDataList[numMaterials]->setID( stoi(stringlist[1]) );

          MatlDataList[numMaterials]->SolnData = &(SolnData);
          
          vecTempDbl.clear();
          for(ii=0; ii<stringlist.size()-2; ii++)
              vecTempDbl.push_back( stod(stringlist[2+ii]) );

          MatlDataList[numMaterials]->setData(vecTempDbl);

          numMaterials++;

          cout << "numMaterials = " << numMaterials << endl;
      }
      //
      //
      else if(stringlist[0] == "SPC1")
      {
      }
    }
    
    nNode_global = nodecoords.size();
    nElem_global = elemConn.size();

    GeomData.setDimension(ndim);
    GeomData.setNodalPositions(nodecoords);


    return 0;
}





