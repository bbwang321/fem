/*
! Program for solid mechanics using FEM
!
!
! Author: Dr. Chennakesava Kadapa
! Date  : 23-November-2023
! Place : Edinburgh, UK
!
!
*/


#include "headersVTK.h"
#include "headersBasic.h"
#include "femSolids.h"
#include <unistd.h>
#include "Global.h"
#include <boost/algorithm/string.hpp>


using namespace std;



int main(int argc, char* argv[])
{
    if(argc == 0)
    {
      PetscPrintf(MPI_COMM_WORLD, "\n    No input file is specified ... \n ");
      PetscPrintf(MPI_COMM_WORLD, "\n    Aborting the program ... \n ");
      return 1;
    }

    //
    // PETSc options file
    //
    string  petscfile     = "petsc_options.dat";

    ifstream finpetscfile(petscfile);
    if(finpetscfile.fail())
    {
      PetscPrintf(MPI_COMM_WORLD, "\n    PETSc options file is not available ... \n ");
      exit(1);
    }
    PetscInitialize(NULL, NULL, petscfile.c_str(), NULL);



    //
    // Input file
    //
    string  inpfilename = argv[1];

    PetscPrintf(MPI_COMM_WORLD, "\n\n\n    Input file ... %s \n\n\n", inpfilename.c_str());

    ifstream fin(inpfilename);
    if(fin.fail())
    {
      PetscPrintf(MPI_COMM_WORLD, "\n    Could not open the input file ... \n ");
      exit(1);
    }


    // get the input file extension to choose the reader function
    vector<string>  stringlist;
    boost::algorithm::split(stringlist, inpfilename, boost::is_any_of("."), boost::token_compress_on);
    for(auto& str: stringlist)  boost::trim(str);

    string ext = stringlist[stringlist.size()-1];


    femSolids  solidfem;

    solidfem.setJobName(stringlist[0]);

    if( ext == "kck" )
      solidfem.readInputMine(fin);
    else if( ext == "bdf" )
      solidfem.readInputBDF(fin);
    else
    {
      PetscPrintf(MPI_COMM_WORLD, "\n    No support for this type of input file format yet ... \n ");
    }

    finpetscfile.close();
    fin.close();

    solidfem.prepareInputData();

    solidfem.setSolver(2);

    solidfem.solveFullyImplicit();

    //solidfem.postProcess();

    PetscPrintf(MPI_COMM_WORLD, "\n\n\n Program is successful \n\n\n ");

    // this needs to done explicitly. Otherwise all the allocated PETSc objects will not be destroyed.
    solidfem.deallocatePetscObjects();
    MPI_Barrier(MPI_COMM_WORLD);

    PetscFinalize();

    return 0;
}
